import pandas as pd
from rapid import preclean_sijk, merge_sijk_to_sf

# ==============================
# SAMPLE DATA
# ==============================
# File Utama (SF)
data_sf = [
    {"nm_prov": "AA", "nm_kab": "AI", "nama_perusahaan": "PT ALPHA",
        "alamat_perusahaan": "Jl. Merdeka 1", "npwp": "123", "skala_usaha": "", "badan_usaha": ""},
    {"nm_prov": "BB", "nm_kab": "BI", "nama_perusahaan": "PT BETA",
        "alamat_perusahaan": "Jl. Sudirman 2", "npwp": "456", "skala_usaha": "2", "badan_usaha": "2"},
]
df_sf = pd.DataFrame(data_sf)

# SIJK
data_sijk = [
    # Sama persis dg SF -> harus enrich, bukan append
    {"nm_prov": "AA", "nm_kab": "AI", "nama_perusahaan": "PT ALPHA",
        "alamat_perusahaan": "Jl. Merdeka 1", "npwp": "123", "skala_usaha": "3", "badan_usaha": "2"},
    # Baru, belum ada di SF -> append
    {"nm_prov": "CC", "nm_kab": "CI", "nama_perusahaan": "PT GAMMA",
        "alamat_perusahaan": "Jl. Thamrin 3", "npwp": "789", "skala_usaha": "1", "badan_usaha": "1"},
    # Duplikat internal SIJK -> harus dihapus salah satu
    {"nm_prov": "CC", "nm_kab": "CI", "nama_perusahaan": "PT GAMMA",
        "alamat_perusahaan": "Jl. Thamrin 3", "npwp": "789", "skala_usaha": "1", "badan_usaha": "1"},
]
df_sijk = pd.DataFrame(data_sijk)

# LPSE
data_lpse = [
    {"nm_prov": "DD", "nm_kab": "DI", "nama_perusahaan": "PT DELTA", "alamat_perusahaan": "Jl. Gatot Subroto 4",
        "npwp": "999", "skala_usaha": "2", "badan_usaha": "2", "kd_penyedia": "001"},
    {"nm_prov": "DD", "nm_kab": "DI", "nama_perusahaan": "PT DELTA", "alamat_perusahaan": "Jl. Gatot Subroto 4",
        "npwp": "999", "skala_usaha": "2", "badan_usaha": "2", "kd_penyedia": "001"},  # duplikat
]
df_lpse = pd.DataFrame(data_lpse)

print("=== SF ASLI ===")
print(df_sf, "\n")

# ==============================
# 1. PRE-CLEANING SIJK
# ==============================
df_sijk_clean = preclean_sijk(df_sijk, threshold=75)
print("=== SIJK SETELAH PRE-CLEANING (hapus duplikat internal) ===")
print(df_sijk_clean, "\n")

# ==============================
# 2. MERGE SIJK KE SF
# ==============================
df_sf_after_merge = merge_sijk_to_sf(df_sf, df_sijk_clean, threshold=75)
print("=== SF SETELAH MERGE SIJK (field-level merge & append baru) ===")
print(df_sf_after_merge, "\n")

# ==============================
# 3. PRE-CLEANING LPSE
# ==============================
df_lpse_clean = df_lpse.drop_duplicates(subset=["kd_penyedia"])
print("=== LPSE SETELAH HAPUS DUPLIKAT kd_penyedia ===")
print(df_lpse_clean, "\n")

# ==============================
# 4. FINAL GABUNG SF + LPSE
# ==============================
df_final = pd.concat([df_sf_after_merge, df_lpse_clean], ignore_index=True)
print("=== HASIL FINAL GABUNG SF + SIJK + LPSE ===")
print(df_final, "\n")
